If Using virtualenv(Optional)
=============================
pip install virtualenv

Virtualenv env

cd env

source bin/activate



Installation Process
====================

pip install django

pip install Pillow



Run Project(commands)
=====================

cd homelyproj

python manage.py makemigrations

python manage.py migrate

python manage.py runserver



