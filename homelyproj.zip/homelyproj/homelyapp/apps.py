from django.apps import AppConfig


class HomelyappConfig(AppConfig):
    name = 'homelyapp'
